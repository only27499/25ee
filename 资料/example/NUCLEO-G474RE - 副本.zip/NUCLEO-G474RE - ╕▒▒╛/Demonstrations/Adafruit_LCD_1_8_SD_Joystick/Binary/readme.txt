/**
  ******************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Binary resource readme file.
  ******************************************************************************
  */

The binary demonstration files are available from the NUCLEO-G474RE page in the Binary Resources section.

Please refer to: https://www.st.com/en/product/nucleo-g474re.html